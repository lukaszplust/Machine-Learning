import copy
import sys
from exceptions import AgentException


class AlphaBetaAgent:
    def __init__(self, my_token='o', depth=4, eval_mode='basic'):
        self.my_token = my_token
        self.opponent_token = 'x' if my_token == 'o' else 'o'
        self.depth = depth
        self.eval_mode = eval_mode

    def decide(self, connect4):

        # sprawdzam czy ruch jest dla aktualnego gracza
        if connect4.who_moves != self.my_token:
            raise AgentException('not my round')

        # tworze listę możliwych ruchów dla aktualnego stanu gry
        valid_moves = connect4.possible_drops()

        # Tworze głęboką kopię obiektu connect4,
        # aby algorytm alphbeta mógł analizować stan gry bez zmiany stanu oryginalnej gry.
        _, best_move = self.alphabeta(connect4, self.depth, -sys.maxsize, sys.maxsize, self.my_token)

        # sprawdzam czy najlepszy ruch znajduje sie na liscie mozliwych ruchow
        if best_move not in valid_moves:
            # jesli nie to wybieram pierwszy mozliwy ruch
            best_move = valid_moves[0]

        return best_move


    # alpha: wartość, która reprezentuje najlepszą wartość,
    # jaką gracz maksymalizujący (MinMaxAgent) może osiągnąć

    # beta: wartość, która reprezentuje najlepszą wartość,
    # jaką gracz minimalizujący (przeciwnik) może osiągnąć
    def alphabeta(self, connect4, depth, alpha, beta, player):

        if depth == 0 or connect4.game_over:
            return self.evaluate(connect4), None

        # jesli aktualny gracz jest graczem kontrolowanym przez obiekt minmaxagent
        if player == self.my_token:
            # wartosc najlepsza ustawiam na najmniejsza
            best_value = -sys.maxsize
            best_move = None

            # przechodze przez wszystkie mozliwe ruchy
            for move in connect4.possible_drops():

                # nowa kopia stanu gry
                new_connect4 = copy.deepcopy(connect4)

                # wykonuje ruch
                new_connect4.drop_token(move)

                #rekurencyjnie wywoluje alphabeta dla przeciwnika z nowym stanem gry i glebokoscia o 1 mniejsza
                # ma to na celu wyszukanie najlepszej wartosci oceny dla przeciwnika
                value, _ = self.alphabeta(new_connect4, depth - 1, alpha, beta, self.opponent_token)

                #jesli wartosc oceny przeciwnika jest wieksza od najlepszej wartosci
                if value > best_value:
                    #to zmieniam wartosc
                    best_value = value

                    #aktualizuje rowniez best_move nowym move
                    best_move = move

                #aktualizuje wartosc alhpa nowa wartoscia best_value
                # alpha reprezentuje najlepszą wartość, jaką gracz maksymalizujący może osiągnąć

                alpha = max(alpha, best_value)

                # beta reprezentuje wartosc

                # Sprawdzamy, czy wartość beta (reprezentująca najlepszą wartość, jaką gracz minimalizujący może osiągnąć) jest mniejsza lub równa alpha.

                # Jeśli tak, następuje odcięcie(pruning) beta, ponieważ przeciwnik nie będzie wybierał tej ścieżki (wartość
                # na tej ścieżce jest gorsza lub równa niż wartość najlepszej dotychczasowej ścieżki dla przeciwnika).

                # i takim przypadku przerywamy dalsze iteracje.

                # Gdy wartość beta jest mniejsza lub równa alfa, to oznacza, że przeciwnik ma już lepszą opcję (wartość beta) niż ta,
                # którą sprawdzamy, i nie ma sensu kontynuować przeszukiwania dla tej gałęzi, ponieważ wartość,
                # którą sprawdzamy, nie może być wybrana przez przeciwnika.
                #
                # dlatego odcinanie następuje w momencie, gdy wartość beta jest mniejsza lub równa wartości alfa.
                if beta <= alpha:
                    break
            return best_value, best_move

        else:
            # inicjalizuje best_value na maksymalną możliwą wartość, aby zapewnić,
            # że pierwsza wartość, którą znajdziemy, będzie zawsze lepsza

            best_value = sys.maxsize
            best_move = None

            # przechodze przez wszystkie mozliwe ruchy
            for move in connect4.possible_drops():

                # nowa kopia stanu gry
                new_connect4 = copy.deepcopy(connect4)
                # wykonuje ruch
                new_connect4.drop_token(move)
                # wywoluje rekurencyjnie alphabeta
                value, _ = self.alphabeta(new_connect4, depth - 1, alpha, beta, self.my_token)

                if value < best_value:
                    best_value = value
                    best_move = move

                # aktualizuje wartosc beta nowa wartoscia best_value
                # beta reprezentuje najlepszą wartość, jaką gracz minimalizujacy (przeciwnik) może osiągnąć
                beta = min(beta, best_value)

                # Gdy wartość beta jest mniejsza lub równa alfa, to oznacza, że przeciwnik ma już lepszą opcję (wartość beta) niż ta,
                # którą sprawdzamy, i nie ma sensu kontynuować przeszukiwania dla tej gałęzi, ponieważ wartość,
                # którą sprawdzamy, nie może być wybrana przez przeciwnika.
                #
                # dlatego odcinanie następuje w momencie, gdy wartość beta jest mniejsza lub równa wartości alfa

                if beta <= alpha:
                    break
            return best_value, best_move

    def evaluate(self, connect4):

        # jesli eval_mode ma wartosc advanced to zostanie uzyta metoda "advanced_static_eval" do oceny stanu gry
        # jesli nie to basic
        return self.advanced_static_eval(connect4) if self.eval_mode == 'advanced' else self.basic_static_eval(connect4)

    def basic_static_eval(self, connect4):

        # wartosc maksymalna jest zwracana jesli stan gry jest wygrana dla gracza , jesli dla przeciwnika to najmniejsza

        return sys.maxsize if connect4.wins == self.my_token else (
            -sys.maxsize if connect4.wins == self.opponent_token else 0)

    def advanced_static_eval(self, connect4):

        # iter_fours ->> która generuje wszystkie możliwe zestawy czterech żetonów na planszy w grze Connect Four.
        # 1-> jest zwracana jesli warunek jest spelniony
        # przechodze przez zestawy wygranych i sprawdzam czy jest jakis znak gracza i czy nie ma zadnego zetonu przeciwnika wtedy to potencjalna wygrana
        my_potential_wins = sum(1 for four in connect4.iter_fours() if
                                four.count(self.my_token) > 0 and four.count(self.opponent_token) == 0)
        # analogicznie robie dla przeciwnika
        opponent_potential_wins = sum(1 for four in connect4.iter_fours() if
                                      four.count(self.opponent_token) > 0 and four.count(self.my_token) == 0)

        # sys.maxsize -> najwieksza mozliwa wartosc w pythonie
        # jesli aktualny stan gry jest wygrana dla gracza to jest zwracana ta najwieksza wartosc, jesli nie to najmniejsza wartosc

        # jesli aktualny stan gry nie jest wygrana dla gracza ani dla przeciwnika to jeśli gracz ma więcej potencjalnych wygranych,
        # to zwracana wartość będzie dodatnia;
        # jeśli przeciwnik ma więcej potencjalnych wygranych, to zwracana wartość będzie ujemna
        return sys.maxsize if connect4.wins == self.my_token else -sys.maxsize if connect4.wins == self.opponent_token else my_potential_wins - opponent_potential_wins
