import sys
import copy
from exceptions import AgentException

class MinMaxAgent:
    def __init__(self, my_token='o', depth=4, eval_mode='basic'):
        self.my_token = my_token
        self.opponent_token = 'x' if my_token == 'o' else 'o'
        self.depth = depth
        self.eval_mode = eval_mode

    def decide(self, connect4):

        #sprawdzam czy ruch jest dla aktualnego gracza
        if connect4.who_moves != self.my_token:
            raise AgentException('not my round')

        # tworze listę możliwych ruchów dla aktualnego stanu gry
        valid_moves = connect4.possible_drops()

        # Tworze głęboką kopię obiektu connect4,
        # aby algorytm minmax mógł analizować stan gry bez zmiany stanu oryginalnej gry.
        _, best_move = self.minmax(copy.deepcopy(connect4), self.depth, self.my_token)

        #sprawdzam czy najlepszy ruch znajduje sie na liscie mozliwych ruchow
        if best_move not in valid_moves:
            #jesli nie to wybieram pierwszy mozliwy ruch
            best_move = valid_moves[0]

        return best_move

    def minmax(self, connect4, depth, player):

        #jesli glebokosc t 0 lub koniec gry to zwracana jest wartość heurystyczna oceny stanu gry
        # za pomocą funkcji evaluate oraz None, ponieważ nie ma ruchu do zwrócenia.

        if depth == 0 or connect4.game_over:
            return self.evaluate(connect4), None

        # najlepsza wartosc to namniejsza mozliwa dla gracza, a dla przeciwnika na najwieksza
        best_value = -sys.maxsize if player == self.my_token else sys.maxsize
        best_move = None

        # przechodze w petli przez kazdy mozliwy ruch
        for move in connect4.possible_drops():

            # nowa kopia stanu gry
            new_connect4 = copy.deepcopy(connect4)

            #wykonuje ruch
            new_connect4.drop_token(move)

            # value -> wartosc oceny aktualnego stanu gry
            #rekurencyjnie wywołuje minmax dla przeciwnika z nowym stanem gry i glebokoscia o 1 mniejsza
            # ma to na celu wyszukanie najlepszej wartosci oceny dla przeciwnika
            value, _ = self.minmax(new_connect4, depth - 1, self.opponent_token if player == self.my_token else self.my_token)

            #sprwadzam czy aktualny gracz jest tym z minmaxagent i czy wartosc dla aktualnego ruchu jest wieksza niz niz najlepsza wartosc
            # jesli te warinki są spełnione to oznacza ze znaleziono lepszy ruch dla gracza z minmaxagent

            # lub sprawdzany jest warunek gdy gracz nie jest kontrolowany przez obiekt (czyli przeciwnik)
            # i jego wartosc jest mniejsza od tej najlepszej
            # dzieki temu wybieram ruch, który minimalizuje wartość oceny dla przeciwnika.
            if (player == self.my_token and value > best_value) or (player != self.my_token and value < best_value):
                best_value, best_move = value, move
        return best_value, best_move

    def evaluate(self, connect4):

        # jesli eval_mode ma wartosc advanced to zostanie uzyta metoda "advanced_static_eval" do oceny stanu gry
        # jesli nie to basic
        return self.advanced_static_eval(connect4) if self.eval_mode == 'advanced' else self.basic_static_eval(connect4)

    def basic_static_eval(self, connect4):

        # wartosc maksymalna jest zwracana jesli stan gry jest wygrana dla gracza , jesli dla przeciwnika to najmniejsza

        return sys.maxsize if connect4.wins == self.my_token else (-sys.maxsize if connect4.wins == self.opponent_token else 0)

    def advanced_static_eval(self, connect4):

        # iter_fours ->> która generuje wszystkie możliwe zestawy czterech żetonów na planszy w grze Connect Four.
        # 1-> jest zwracana jesli warunek jest spelniony
        #przechodze przez zestawy wygranych i sprawdzam czy jest jakis znak gracza i czy nie ma zadnego zetonu przeciwnika wtedy to potencjalna wygrana
        my_potential_wins = sum(1 for four in connect4.iter_fours() if four.count(self.my_token) > 0 and four.count(self.opponent_token) == 0)
        #analogicznie robie dla przeciwnika
        opponent_potential_wins = sum(1 for four in connect4.iter_fours() if four.count(self.opponent_token) > 0 and four.count(self.my_token) == 0)

        #sys.maxsize -> najwieksza mozliwa wartosc w pythonie
        # jesli aktualny stan gry jest wygrana dla gracza to jest zwracana ta najwieksza wartosc, jesli nie to najmniejsza wartosc

        # jesli aktualny stan gry nie jest wygrana dla gracza ani dla przeciwnika to jeśli gracz ma więcej potencjalnych wygranych,
        # to zwracana wartość będzie dodatnia;
        # jeśli przeciwnik ma więcej potencjalnych wygranych, to zwracana wartość będzie ujemna
        return sys.maxsize if connect4.wins == self.my_token else -sys.maxsize if connect4.wins == self.opponent_token else my_potential_wins - opponent_potential_wins
